import React from 'react';
import AppStyles from './App.module.css';

import { BrowserRouter as Router, Route, Switch, Redirect, useHistory } from 'react-router-dom';

import { useDispatch, useSelector } from "react-redux";
import { getIngredientsData } from '../../services/actions/burgerIngredients';
import { authorizeUser } from '../../services/actions/currentSession';

import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

import ProtectedRoute from '../../utils/ProtectedRoute';
import AppHeader from '../AppHeader/AppHeader';
import BurgerIngredients from '../BurgerIngredients/BurgerIngredietns';
import BurgerConstructor from '../BurgerConstructor/BurgerConstructor';
import Account from '../../pages/Account/Account';

import Login from '../../pages/Authorization/Login';
import Register from '../../pages/Authorization/Register';
import ForgotPassword from '../../pages/Authorization/ForgotPassword';
import RecoverPassword from '../../pages/Authorization/RecoverPassword';

import IngredientDetails from '../Modal/IngredientDetails';
import OrderDetails from '../Modal/OrderDetails';
import Modal from '../Modal/Modal';
import Loading from '../Modal/Loading';
import { loginApi } from '../../utils/LoginApi';

function App() {

  const [ isModalOpenIngredients, setModalOpenIngredients ] = React.useState(false);
  const [ isModalOpenOrder, setModalOpenOrder ] = React.useState(false);

  const dispatch = useDispatch();
  const history = useHistory();

  const isUserAuth = useSelector(
    (state) => state.currentSession.isCurrentUserAuth
  );

  const isPageLoading = useSelector(
    (state) => state.burgerIngredients.isPageLoading
  );

  const isOrderLoading = useSelector(
    (state) => state.burgerConstructor.isPageLoading
  );

  const isAccountLoading = useSelector(
    (state) => state.currentSession.isAccountLoading
  )

  const isUserResetPassword = useSelector(
    (state) => state.currentSession.isUserResetPassword
  );

  function handleModalOpenIngredients() {
    setModalOpenIngredients(true);
  };

  function handleModalCloseIngredients() {
    setModalOpenIngredients(false);
  };

  function handleModalOpenOrder() {
    setModalOpenOrder(true);
  };

  function handleModalCloseOrder() {
    setModalOpenOrder(false);
  };

  const IngredientModal = (
    <IngredientDetails
      closeModal={handleModalCloseIngredients}
    />
  );

  const OrderModal = (
    <OrderDetails
      closeModal={handleModalCloseOrder}
    />
  );

  function refreshToken() {
    if(isUserAuth === false) {
      loginApi.updateToken()
        .then((data) => {
          localStorage.setItem('accessToken', data.accessToken)
          console.log('token refresh success')
        })
        .catch((err) => {
          console.log(err);
          dispatch(authorizeUser(false));
        })
    }
  }

  React.useEffect(() => {
    dispatch(getIngredientsData());
  }, [dispatch]);

  React.useEffect(() => {
    let jwt = localStorage.getItem('refreshToken')
    if(jwt) {
      loginApi.getUserInfo()
      .then(() => {
        dispatch(authorizeUser(true));
        history.push('/');
      })
      .catch((err) => {
        console.log(err);
        // if(err.message === 'jwt expired') {
        //   refreshToken();
        // }
      })
    }
  });

  return (
    <div className={AppStyles.App}>
      <Router>
      <AppHeader />
      <main className={AppStyles.componentContainer}>
        <Switch>
          <ProtectedRoute path="/" exact={true} loggedIn={isUserAuth} redirect={false}>
            <DndProvider backend={HTML5Backend}>
              <BurgerIngredients
                openModal = {handleModalOpenIngredients}
              />
              <BurgerConstructor    
                openModal = {handleModalOpenOrder}
              />
            </DndProvider>
          </ProtectedRoute>
          <ProtectedRoute path="/account" loggedIn={isUserAuth} redirect={false}>
            <Account />
          </ProtectedRoute>
          <Route path="/login">
            <Login />
          </Route>
          <Route path="/register">
            <Register />
          </Route>
          <Route path="/forgot-password">
            <ForgotPassword />
          </Route>
          <ProtectedRoute loggedIn={isUserResetPassword} path="/reset-password" redirect={true}>
            <RecoverPassword />
          </ProtectedRoute>
          {
            isUserAuth ? <Redirect to="/"/> : <Redirect to="/login"/>
          }
        </Switch>
      </main>
      </Router>
      <Modal 
        isOpen={isModalOpenIngredients}
        closeModal={handleModalCloseIngredients}
        children={IngredientModal}
      />
      <Modal
        isOpen={isModalOpenOrder}
        closeModal={handleModalCloseOrder}
        children={OrderModal}
      />
      <Loading 
        isOpen = {isPageLoading || isOrderLoading || isAccountLoading}
      />
    </div>
  );
}

export default App;

import NotFoundStyles from './NotFound.module.css';

function NotFound() {

  return (
    <div className={NotFoundStyles.notFound}>
    </div>
  );
}

export default NotFound;
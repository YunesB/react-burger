import React from 'react';

export const IngredientsContext = React.createContext();
export const OrderContext = React.createContext();